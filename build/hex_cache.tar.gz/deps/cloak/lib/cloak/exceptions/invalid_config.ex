defmodule Cloak.InvalidConfig do
  @moduledoc "Raised when there is invalid configuration."
  defexception [:message]
end
